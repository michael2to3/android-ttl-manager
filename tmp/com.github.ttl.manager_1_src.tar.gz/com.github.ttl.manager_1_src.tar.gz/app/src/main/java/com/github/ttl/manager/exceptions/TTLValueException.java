package com.github.ttl.manager.exceptions;

public class TTLValueException extends Exception {
    public TTLValueException(String message) {
        super(message);
    }
}