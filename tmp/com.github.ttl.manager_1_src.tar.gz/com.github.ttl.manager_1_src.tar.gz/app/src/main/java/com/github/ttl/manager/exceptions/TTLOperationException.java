package com.github.ttl.manager.exceptions;

public class TTLOperationException extends Exception {
    public TTLOperationException(String message, Throwable cause) {
        super(message, cause);
    }
}
