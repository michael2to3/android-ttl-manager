package com.github.ttl.manager.exceptions;

public class RootAccessException extends Exception {
    public RootAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}